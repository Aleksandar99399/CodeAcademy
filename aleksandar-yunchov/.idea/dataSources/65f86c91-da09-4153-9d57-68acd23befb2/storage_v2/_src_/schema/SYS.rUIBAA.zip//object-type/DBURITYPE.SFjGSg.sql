create type DBUriType                                       
  authid current_user under sys.UriType
(
 -- url varchar2(4000),
  spare raw(2000),
  overriding member function getExternalUrl return varchar2 deterministic,
  overriding member function getUrl return varchar2 deterministic,
  -- returns the clob value of the pointed to URL
  overriding member function getClob RETURN clob,
  overriding member function getBlob RETURN blob,
  overriding member function getBlob(csid IN NUMBER) RETURN blob,
  static function createuri(dburi in varchar2) return dburitype,
  -- new fcns in 9.2
  overriding member function getXML return sys.XMLType,
  constructor function DBUriType(url in varchar2, spare in raw := null)
    return self as result,
  overriding member function getContentType RETURN varchar2,
  overriding member function getClob(content OUT varchar2) RETURN clob,
  overriding member function getBlob(content OUT varchar2) RETURN blob,
  overriding member function getXML(content OUT varchar2)
    RETURN sys.XMLType
);
/

