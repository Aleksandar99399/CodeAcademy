create PROCEDURE dbms_feature_afd
      (is_used OUT number, aux_count OUT number, feature_info OUT clob)
AS
BEGIN
  select count(*) into is_used
         from v$asm_disk where path LIKE 'AFD:%' AND
                               state = 'NORMAL' AND
                               library LIKE '%AFD Library%' AND
                               mount_status = 'CACHED' AND
                               group_number != '0';
END;
/

