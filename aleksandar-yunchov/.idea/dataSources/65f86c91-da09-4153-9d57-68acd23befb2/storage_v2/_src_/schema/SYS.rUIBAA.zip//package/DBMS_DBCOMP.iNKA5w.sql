create PACKAGE DBMS_DBCOMP AUTHID CURRENT_USER IS

-- DE-HEAD     <- tell SED where to cut when generating fixed package

PROCEDURE DBCOMP(datafile IN varchar2
                ,outputfile IN varchar2
                ,block_dump IN boolean := false);

-------------------------------------------------------------------------------
  pragma TIMESTAMP('2013-06-29:18:43:00');
-------------------------------------------------------------------------------



END;

-- CUT_HERE    <- tell sed where to chop off the rest
/

