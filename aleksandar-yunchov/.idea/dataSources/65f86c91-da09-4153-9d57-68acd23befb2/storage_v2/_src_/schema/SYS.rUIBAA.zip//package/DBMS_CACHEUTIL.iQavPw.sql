create PACKAGE dbms_cacheutil AS

-- DE-HEAD  <- tell SED where to cut when generating fixed package

--*****************************************************************************
-- Package Public Exceptions
--*****************************************************************************

--*****************************************************************************
-- Package Public Types
--*****************************************************************************
-------------------------------------------------------------------------------
--
-- PROCEDURE     grab_affinity
--
-- Description:  try to grab object affinity in RAC environment
--
-- Parameters:
--
-------------------------------------------------------------------------------
PROCEDURE grab_affinity( schema     IN varchar2,
                         obj        IN varchar2,
                         partition  IN varchar2 := null,
                         grab_index IN boolean := TRUE,
                         active_drm IN boolean := FALSE);

-------------------------------------------------------------------------------
--
-- PROCEDURE     grab_readmostly
--
-- Description:  try to grab object readmostly in RAC environment
--
-- Parameters:
--
-------------------------------------------------------------------------------
PROCEDURE grab_readmostly( schema     IN varchar2,
                           obj        IN varchar2,
                           partition  IN varchar2 := null,
                           grab_index IN boolean := TRUE);

-------------------------------------------------------------------------------
--
-- PROCEDURE     dissolve_affinity
--
-- Description:  try to dissolve object affinity in RAC environment
--
-- Parameters:
--
-------------------------------------------------------------------------------
PROCEDURE dissolve_affinity( schema         IN varchar2,
                             obj            IN varchar2,
                             partition      IN varchar2 := null,
                             dissolve_index IN boolean := TRUE,
                             active_drm     IN boolean := FALSE);

-------------------------------------------------------------------------------
--
-- PROCEDURE     dissolve_readmostly
--
-- Description:  try to dissolve object readmostly in RAC environment
--
-- Parameters:
--
-------------------------------------------------------------------------------
PROCEDURE dissolve_readmostly( schema         IN varchar2,
                               obj            IN varchar2,
                               partition      IN varchar2 := null,
                               dissolve_index IN boolean := TRUE);

-------------------------------------------------------------------------------
--
-- PROCEDURE     list_readmostly
--
-- Description:  list objects have readmostly property set
--
-- Parameters:
--
-------------------------------------------------------------------------------
PROCEDURE list_readmostly;

-------------------------------------------------------------------------------
--
-- PROCEDURE     object_downconvert
--
-- Description:  try to downconvert object locks to shared mode in RAC
--
-- Parameters:
--
-------------------------------------------------------------------------------
PROCEDURE object_downconvert( schema            IN varchar2,
                              obj               IN varchar2,
                              partition         IN varchar2 := null,
                              downconvert_index IN boolean := TRUE);


END;

-- CUT_HERE    <- tell sed where to chop off the rest
/

