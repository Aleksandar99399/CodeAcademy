create TYPE     aq$_ntfn_descriptor FORCE AS OBJECT (
        ntfn_flags         number)                     -- flags
/

