create PACKAGE dbms_aq_imp_zecurity wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
9
6f b6
/HuscYkUI5TWwvG/k/w0zjjhiN8wg5RHLcusfC+macE/lXNb60LtUOj7/A1sr0Nm/N1n4U3W
PwBlnV3pGqkqagtuDyO6MuwfcwC7T3kjqvsMnxnhlPNIA6fb4XVf++Ml8wVmdF11rJIbn/Eq
GLvVC1MNcHIuCTR2Uer5HyIoPd5b8EHKHg==
/

