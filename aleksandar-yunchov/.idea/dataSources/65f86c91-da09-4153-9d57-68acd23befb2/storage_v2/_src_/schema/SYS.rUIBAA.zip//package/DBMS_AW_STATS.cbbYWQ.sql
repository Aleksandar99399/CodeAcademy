create PACKAGE dbms_aw_stats AUTHID CURRENT_USER AS

  --
  -- ERROR NUMBERS
  --
  -- Note : DBMS_OUTPUT, DBMS_DESCRIBE and DBMS_AW (maybe others) use
  -- the application error numbers -20001 to -20005 for there own purposes
  --

  aw_error CONSTANT NUMBER := -20001;

  --
  -- PUBLIC INTERFACE
  --

  PROCEDURE analyze(inName IN VARCHAR2);
  PROCEDURE clear(inName IN VARCHAR2);
END dbms_aw_stats;
/

