create TYPE adr_msg_template_t AS OBJECT
(
  org_id                 VARCHAR2(64),                    /* organization id */
  component_id           VARCHAR2(64),                       /* component id */
  instance_id            VARCHAR2(64),                        /* instance id */
  hosting_client_id      VARCHAR2(64),                  /* hosting client id */
  msg_group              VARCHAR2(64),                      /* message group */
  host_id                VARCHAR2(64),                            /* host id */
  host_nwaddr            VARCHAR2(46),                       /* host address */
  module_id              VARCHAR2(64),                         /* module id  */
  process_id             VARCHAR2(32),                        /* process id  */
  thread_id              VARCHAR2(64),                         /* thread id  */
  user_id                VARCHAR2(128),                          /* user id  */
  upstream_comp_id       VARCHAR2(64),             /* upstream component id  */
  downstream_comp_id     VARCHAR2(64),           /* downstream component id  */
  ecid                   adr_log_msg_ecid_t,        /* execution context id  */
  error_instance_id      adr_log_msg_errid_t,          /* error instance id  */
  msg_args               adr_log_msg_args_t,           /* message arguments  */
  detail_location        VARCHAR2(160),                /* detailed location  */
  suppl_detail           VARCHAR2(128),             /* supplemental details  */
  -- CDB fields
  con_uid                INTEGER,                     /* container unique ID */
  con_id                 INTEGER,                            /* container ID */
  con_name               VARCHAR2(30)                      /* container name */
);
/

