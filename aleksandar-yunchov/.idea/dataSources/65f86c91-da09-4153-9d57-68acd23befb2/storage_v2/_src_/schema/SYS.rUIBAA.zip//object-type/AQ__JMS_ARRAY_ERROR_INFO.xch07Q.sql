create type aq$_jms_array_error_info
                                                                      
as object
(
   error_position    int,
   error_no          int,
   error_msg         varchar2(4000)
);
/

