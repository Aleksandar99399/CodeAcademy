create package     CDBView as
  ----------------------------
  --  PROCEDURES AND FUNCTIONS
  --
procedure create_cdbview(chk_upgrd IN boolean, owner IN varchar2,
                         oldview_name IN varchar2, newview_name IN varchar2);

function getlong(opcode in number, p_rowid in rowid) return varchar2;
--  accessible by(FUNCTION SYS.GETLONG);
pragma restrict_references (getlong, WNPS, RNPS, WNDS, TRUST);

end CDBView;
/

