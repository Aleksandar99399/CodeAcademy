create type dbms_dbfs_content_list_item_t
    authid definer
as object (
    path        varchar2(1024),
    item_name   varchar2(256),
    item_type   integer
);
/

