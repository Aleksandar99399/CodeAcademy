create type dg$row force as object
(JPATH   VARCHAR2(4000),
 JTYPE   VARCHAR2(40),
 TLENGTH NUMBER);
/

