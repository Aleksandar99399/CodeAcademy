create PACKAGE BODY dbms_awr_protected wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
b
6e ae
jVQ1cTsAztmLehAEe0MeQL1VwzEwg7LZNZ4VZ3SmZ3IQ6Rk4CMhIUTa/tyVW44esgxzpJkSd
uxVxF9v11LZqcPUCOgiS1HPE1BcQINnHuslnu6bskWN1QMfl4PyoxVx82fAmTNlfnvgddn/a
/qTV+7KVHZZeX7c9PHWSVSyU/CxS
/

