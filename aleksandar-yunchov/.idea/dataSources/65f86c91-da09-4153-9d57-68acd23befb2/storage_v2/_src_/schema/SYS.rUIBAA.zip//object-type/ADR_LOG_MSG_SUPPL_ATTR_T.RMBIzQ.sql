create TYPE adr_log_msg_suppl_attr_t FORCE AS OBJECT
(
  name       VARCHAR2(64),                                 /* attribute name */
  value      VARCHAR2(128)                                /* attribute value */
);
/

