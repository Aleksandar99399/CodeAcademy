create package amgt$datapump
as
  procedure instance_callout_imp(
                      obj_name         in      varchar2,
                      obj_schema       in      varchar2,
                      obj_type         in      number,
                      prepost          in      pls_integer,
                      action           out     varchar2,
                      alt_name         out     varchar2
                      );
end;
/

