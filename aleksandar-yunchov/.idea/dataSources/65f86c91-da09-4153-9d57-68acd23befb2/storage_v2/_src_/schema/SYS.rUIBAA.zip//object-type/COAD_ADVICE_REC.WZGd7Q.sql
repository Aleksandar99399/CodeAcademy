create type coad_advice_rec as OBJECT (
     owner       dbms_id,
     apiObject   dbms_id,
     sqlObjOwn   dbms_id,
     sqlObject   varchar2(261),
     adviceType  number(38,0),
     disposition clob,
     sqlText     clob,
     dropText    clob )
/

