create TYPE adr_log_msg_t AS OBJECT
(
  -- Header attributes
  timestamp_originating  TIMESTAMP WITH TIME ZONE,       /* time originating */
  timestamp_normalized   TIMESTAMP WITH TIME ZONE,        /* time normalized */
  org_id                 VARCHAR2(64),                    /* organization id */
  component_id           VARCHAR2(64),                       /* component id */
  instance_id            VARCHAR2(64),                        /* instance id */
  hosting_client_id      VARCHAR2(64),                  /* hosting client id */
  msg_id                 VARCHAR2(64),                         /* message id */
  msg_type               INTEGER,                            /* message type */
  msg_group              VARCHAR2(64),                      /* message group */
  msg_level              INTEGER,                           /* message level */
  host_id                VARCHAR2(64),                            /* host id */
  host_nwaddr            VARCHAR2(46),                       /* host address */
  module_id              VARCHAR2(64),                         /* module id  */
  process_id             VARCHAR2(32),                        /* process id  */
  thread_id              VARCHAR2(64),                         /* thread id  */
  user_id                VARCHAR2(128),                          /* user id  */
  suppl_attrs            adr_log_msg_suppl_attrs_t,
                                                  /* Supplemental attributes */

  -- Correlation data fields
  problem_key            VARCHAR2(64),                        /* problem key */
  upstream_comp_id       VARCHAR2(64),             /* upstream component id  */
  downstream_comp_id     VARCHAR2(64),           /* downstream component id  */
  ecid                   adr_log_msg_ecid_t,        /* execution context id  */
  error_instance_id      adr_log_msg_errid_t,          /* error instance id  */

  -- Payload
  msg_text               VARCHAR2(2048),                     /* message text */
  msg_args               adr_log_msg_args_t,            /* message arguments */
  detail_location        VARCHAR2(160),                /* detailed location  */
  suppl_detail           VARCHAR2(128),             /* supplemental details  */

  -- CDB fields
  con_uid                INTEGER,                     /* container unique ID */
  con_id                 INTEGER,                            /* container ID */
  con_name               VARCHAR2(30)                      /* container name */
);
/

