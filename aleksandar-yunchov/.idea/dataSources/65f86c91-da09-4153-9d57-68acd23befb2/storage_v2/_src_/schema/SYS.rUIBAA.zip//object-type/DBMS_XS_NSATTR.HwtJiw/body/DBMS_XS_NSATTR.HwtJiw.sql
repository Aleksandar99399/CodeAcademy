create TYPE BODY DBMS_XS_NSATTR AS
  CONSTRUCTOR FUNCTION DBMS_XS_NSATTR(
     namespace         IN VARCHAR2,
     attribute         IN VARCHAR2 DEFAULT NULL,
     attribute_value   IN VARCHAR2 DEFAULT NULL)
  RETURN SELF AS RESULT
  AS
  BEGIN
    SELF.namespace := namespace;
    SELF.attribute := attribute;
    SELF.attribute_value := attribute_value;
    RETURN;
  END;
END;
/

