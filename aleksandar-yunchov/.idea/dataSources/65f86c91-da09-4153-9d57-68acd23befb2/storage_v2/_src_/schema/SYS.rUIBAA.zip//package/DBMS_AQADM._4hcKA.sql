create PACKAGE dbms_aqadm AUTHID CURRENT_USER AS

  --------------------
  --  PUBLIC CONSTANT
  --
  -- payload type of the queue table
  JMS_TYPE             CONSTANT VARCHAR2(10) := 'JMS';

  -- retention
  INFINITE             CONSTANT BINARY_INTEGER := -1;

  -- message grouping
  TRANSACTIONAL        CONSTANT BINARY_INTEGER := 1;
  NONE                 CONSTANT BINARY_INTEGER := 0;

  -- queue type
  NORMAL_QUEUE               CONSTANT BINARY_INTEGER := 0;
  EXCEPTION_QUEUE            CONSTANT BINARY_INTEGER := 1;
  NON_PERSISTENT_QUEUE       CONSTANT BINARY_INTEGER := 2;

  -- non-repudiation properties
  NON_REPUDIATE_SENDER       CONSTANT BINARY_INTEGER := 1;
  NON_REPUDIATE_SNDRCV       CONSTANT BINARY_INTEGER := 2;

  -- protocols (note that FTP is not supported yet so it is not
  -- included in anyp).
  TTC      CONSTANT BINARY_INTEGER := 0;
  HTTP      CONSTANT BINARY_INTEGER := 1;
  SMTP      CONSTANT BINARY_INTEGER := 2;
  FTP       CONSTANT BINARY_INTEGER := 4;
  ANYP      CONSTANT BINARY_INTEGER := HTTP + SMTP;

  LOGMINER_PROTOCOL  CONSTANT BINARY_INTEGER := 1;
  LOGAPPLY_PROTOCOL  CONSTANT BINARY_INTEGER := 2;
  TEST_PROTOCOL      CONSTANT BINARY_INTEGER := 3;

  -- Constants for LDAP connection factory type
  AQ_QUEUE_CONNECTION  CONSTANT BINARY_INTEGER := 1;
  AQ_TOPIC_CONNECTION  CONSTANT BINARY_INTEGER := 2;

  -- Constants for delivery mode
  PERSISTENT         CONSTANT BINARY_INTEGER := 1 ;
  BUFFERED           CONSTANT BINARY_INTEGER := 2 ;
  PERSISTENT_OR_BUFFERED   CONSTANT BINARY_INTEGER := 3 ;

  -- subscriber properties.
  QUEUE_TO_QUEUE_SUBSCRIBER          CONSTANT BINARY_INTEGER := 8;

  -- Constants for get/set_replay_info
  LAST_ENQUEUED      CONSTANT BINARY_INTEGER := 0;
  LAST_ACKNOWLEDGED  CONSTANT BINARY_INTEGER := 1;

  -- 12G sort_list parameter
  -- rearrange sort list values to sync with dbms_aqadm_sys.SC_* and
  -- its corresponding KWSC_* flags in kwsc.h.
  PRIORITY                  CONSTANT BINARY_INTEGER := 1;
  ENQ_TIME                  CONSTANT BINARY_INTEGER := 2;
  PRIORITY_ENQ_TIME         CONSTANT BINARY_INTEGER := 3;
  COMMIT_TIME               CONSTANT BINARY_INTEGER := 4;
  PRIORITY_COMMIT_TIME      CONSTANT BINARY_INTEGER := 5;
  ENQ_TIME_PRIORITY         CONSTANT BINARY_INTEGER := 7;

  -- 12G sharded queue cach hint
  AUTO                      CONSTANT BINARY_INTEGER := 1;
  CACHED                    CONSTANT BINARY_INTEGER := 2;
  UNCACHED                  CONSTANT BINARY_INTEGER := 3;

  -- OGG replicated queue
  -- Queue replication can happen in two ways replication or propagation
  -- when queue is not participating in both , the mode is NONE.
  REPLICATION_MODE    CONSTANT BINARY_INTEGER := 1 ;
  PROPAGATION_MODE    CONSTANT BINARY_INTEGER := 2;
  SWITCHOVER_FORCE    CONSTANT BINARY_INTEGER := 4;

  TYPE aq$_subscriber_list_t IS TABLE OF sys.aq$_agent
    INDEX BY BINARY_INTEGER;

  TYPE aq$_purge_options_t IS
     RECORD(block          boolean      DEFAULT FALSE,
            delivery_mode  PLS_INTEGER  DEFAULT dbms_aqadm.PERSISTENT);

  ------------------------------------------------------------------------
  -- AQ Type definitions

  TYPE QUEUE_PROPS_T IS RECORD (
    queue_type      BINARY_INTEGER DEFAULT NORMAL_QUEUE,
    retry_delay     NUMBER         DEFAULT 0,
    retention_time  NUMBER         DEFAULT 0,
    sort_list       VARCHAR2(30)   DEFAULT NULL,
    cache_hint      BINARY_INTEGER DEFAULT AUTO
    );

  PROCEDURE CREATE_SHARDED_QUEUE (
    queue_name             IN VARCHAR2,
    storage_clause         IN VARCHAR2       DEFAULT NULL,
    multiple_consumers     IN BOOLEAN        DEFAULT FALSE,
    max_retries            IN NUMBER         DEFAULT NULL,
    comment                IN VARCHAR2       DEFAULT NULL,
    queue_payload_type     IN VARCHAR2       DEFAULT JMS_TYPE,
    queue_properties       IN QUEUE_PROPS_T  DEFAULT NULL,
    replication_mode       IN BINARY_INTEGER DEFAULT NONE
    );
  PRAGMA SUPPLEMENTAL_LOG_DATA(CREATE_SHARDED_QUEUE, NONE);

  PROCEDURE CREATE_EXCEPTION_QUEUE(
    sharded_queue_name     IN VARCHAR2,
    exception_queue_name   IN VARCHAR2 DEFAULT NULL
    );
  PRAGMA SUPPLEMENTAL_LOG_DATA(CREATE_EXCEPTION_QUEUE, NONE);


  PROCEDURE ALTER_SHARDED_QUEUE(
    queue_name             IN VARCHAR2,
    max_retries            IN NUMBER         DEFAULT NULL,
    comment                IN VARCHAR2       DEFAULT NULL,
    queue_properties       IN QUEUE_PROPS_T  DEFAULT NULL,
    replication_mode       IN BINARY_INTEGER DEFAULT NONE
    );
  PRAGMA SUPPLEMENTAL_LOG_DATA(ALTER_SHARDED_QUEUE, NONE);

  PROCEDURE  set_queue_parameter(
    queue_name          IN VARCHAR2,
    param_name          IN VARCHAR2,
    param_value         IN NUMBER);


  PROCEDURE unset_queue_parameter(
    queue_name          IN VARCHAR2,
    param_name          IN VARCHAR2);

  PROCEDURE get_queue_parameter(
    queue_name          IN  VARCHAR2,
    param_name          IN  VARCHAR2,
    param_value         OUT NUMBER);

  PROCEDURE create_queue_table(
        queue_table                 IN     VARCHAR2,
        queue_payload_type          IN     VARCHAR2,
        storage_clause              IN     VARCHAR2 DEFAULT NULL,
        sort_list                   IN     VARCHAR2 DEFAULT NULL,
        multiple_consumers          IN     BOOLEAN DEFAULT FALSE,
        message_grouping            IN     BINARY_INTEGER DEFAULT NONE,
        comment                     IN     VARCHAR2 DEFAULT NULL,
        auto_commit                 IN     BOOLEAN  DEFAULT TRUE,
        primary_instance            IN     BINARY_INTEGER DEFAULT 0,
        secondary_instance          IN     BINARY_INTEGER DEFAULT 0,
        compatible                  IN     VARCHAR2 DEFAULT NULL,
        non_repudiation             IN     BINARY_INTEGER DEFAULT 0,
        secure                      IN     BOOLEAN DEFAULT FALSE,
        replication_mode            IN     BINARY_INTEGER DEFAULT NULL);
  PRAGMA SUPPLEMENTAL_LOG_DATA(create_queue_table, NONE);

  PROCEDURE alter_queue_table(
        queue_table                 IN     VARCHAR2,
        comment                     IN     VARCHAR2       DEFAULT NULL,
        primary_instance            IN     BINARY_INTEGER DEFAULT NULL,
        secondary_instance          IN     BINARY_INTEGER DEFAULT NULL,
        replication_mode            IN     BINARY_INTEGER DEFAULT NULL);
  PRAGMA SUPPLEMENTAL_LOG_DATA(alter_queue_table, NONE);

  PROCEDURE create_queue(
        queue_name                  IN     VARCHAR2,
        queue_table                 IN     VARCHAR2,
        queue_type                  IN     BINARY_INTEGER DEFAULT NORMAL_QUEUE,
        max_retries                 IN     NUMBER DEFAULT NULL,
        retry_delay                 IN     NUMBER DEFAULT 0,
        retention_time              IN     NUMBER DEFAULT 0,
        dependency_tracking         IN     BOOLEAN DEFAULT FALSE,
        comment                     IN     VARCHAR2 DEFAULT NULL,
        auto_commit                 IN     BOOLEAN DEFAULT TRUE);
  PRAGMA SUPPLEMENTAL_LOG_DATA(create_queue, NONE);

  PROCEDURE create_np_queue(
        queue_name                  IN     VARCHAR2,
        multiple_consumers          IN     BOOLEAN DEFAULT FALSE,
        comment                     IN     VARCHAR2 DEFAULT NULL);
  PRAGMA SUPPLEMENTAL_LOG_DATA(create_np_queue, NONE);

  PROCEDURE drop_queue(
        queue_name                  IN     VARCHAR2,
        auto_commit                 IN     BOOLEAN DEFAULT TRUE);
  PRAGMA SUPPLEMENTAL_LOG_DATA(drop_queue, NONE);

  PROCEDURE drop_sharded_queue(
        queue_name                  IN     VARCHAR2,
        force                       IN     BOOLEAN DEFAULT FALSE);
  PRAGMA SUPPLEMENTAL_LOG_DATA(drop_sharded_queue, NONE);

  PROCEDURE drop_queue_table(
        queue_table                 IN     VARCHAR2,
        force                       IN     BOOLEAN DEFAULT FALSE,
        auto_commit                 IN     BOOLEAN DEFAULT TRUE);
  PRAGMA SUPPLEMENTAL_LOG_DATA(drop_queue_table, NONE);

  PROCEDURE start_queue(
        queue_name                  IN     VARCHAR2,
        enqueue                     IN     BOOLEAN DEFAULT TRUE,
        dequeue                     IN     BOOLEAN DEFAULT TRUE);
  PRAGMA SUPPLEMENTAL_LOG_DATA(start_queue, NONE);

  PROCEDURE stop_queue(
        queue_name                  IN     VARCHAR2,
        enqueue                     IN     BOOLEAN DEFAULT TRUE,
        dequeue                     IN     BOOLEAN DEFAULT TRUE,
        wait                        IN     BOOLEAN DEFAULT TRUE);
  PRAGMA SUPPLEMENTAL_LOG_DATA(stop_queue, NONE);

  PROCEDURE alter_queue(
        queue_name                  IN     VARCHAR2,
        max_retries                 IN     NUMBER   DEFAULT NULL,
        retry_delay                 IN     NUMBER   DEFAULT NULL,
        retention_time              IN     NUMBER   DEFAULT NULL,
        auto_commit                 IN     BOOLEAN  DEFAULT TRUE,
        comment                     IN     VARCHAR2 DEFAULT NULL);
  PRAGMA SUPPLEMENTAL_LOG_DATA(alter_queue, NONE);

  PROCEDURE add_subscriber(
        queue_name                  IN     VARCHAR2,
        subscriber                  IN     SYS.AQ$_AGENT,
        rule                        IN     VARCHAR2 DEFAULT NULL,
        transformation              IN     VARCHAR2 DEFAULT NULL,
        queue_to_queue              IN     BOOLEAN  DEFAULT FALSE,
        delivery_mode               IN     PLS_INTEGER
                                           DEFAULT PERSISTENT);
  PRAGMA SUPPLEMENTAL_LOG_DATA(add_subscriber, NONE);

  -- for backward compatibility
  PROCEDURE alter_subscriber(
        queue_name                  IN     VARCHAR2,
        subscriber                  IN     SYS.AQ$_AGENT,
        rule                        IN     VARCHAR2);
  PRAGMA SUPPLEMENTAL_LOG_DATA(alter_subscriber, NONE);

  PROCEDURE alter_subscriber(
        queue_name                  IN     VARCHAR2,
        subscriber                  IN     SYS.AQ$_AGENT,
        rule                        IN     VARCHAR2,
        transformation              IN     VARCHAR2);
  PRAGMA SUPPLEMENTAL_LOG_DATA(alter_subscriber, NONE);

  PROCEDURE remove_subscriber(
        queue_name                  IN     VARCHAR2,
        subscriber                  IN     SYS.AQ$_AGENT);
  PRAGMA SUPPLEMENTAL_LOG_DATA(remove_subscriber, NONE);

  PROCEDURE grant_type_access(
        user_name               IN      VARCHAR2);
  PRAGMA SUPPLEMENTAL_LOG_DATA(grant_type_access, AUTO);

  FUNCTION queue_subscribers(
        queue_name              IN      VARCHAR2)
        RETURN aq$_subscriber_list_t;

  PROCEDURE grant_queue_privilege(
        privilege               IN      VARCHAR2,
        queue_name              IN      VARCHAR2,
        grantee                 IN      VARCHAR2,
        grant_option            IN      BOOLEAN := FALSE);
  PRAGMA SUPPLEMENTAL_LOG_DATA(grant_queue_privilege, NONE);

  PROCEDURE grant_system_privilege(
        privilege               IN      VARCHAR2,
        grantee                 IN      VARCHAR2,
        admin_option            IN      BOOLEAN := FALSE);
  PRAGMA SUPPLEMENTAL_LOG_DATA(grant_system_privilege, AUTO);

  PROCEDURE revoke_queue_privilege(
        privilege               IN      VARCHAR2,
        queue_name              IN      VARCHAR2,
        grantee                 IN      VARCHAR2);
  PRAGMA SUPPLEMENTAL_LOG_DATA(revoke_queue_privilege, NONE );

  PROCEDURE revoke_system_privilege(
        privilege               IN      VARCHAR2,
        grantee                 IN      VARCHAR2);
  PRAGMA SUPPLEMENTAL_LOG_DATA(revoke_system_privilege, AUTO);

  PROCEDURE get_type_info(
        schema                      IN     VARCHAR2,
        qname                       IN     VARCHAR2,
        gettds                      IN     BOOLEAN,
        rc                          OUT    BINARY_INTEGER,
        toid                        OUT    RAW,
        version                     OUT    NUMBER,
        tds                         OUT    LONG RAW,
        queue_style                 OUT    VARCHAR2,
        network_name                OUT    VARCHAR2);
  PRAGMA SUPPLEMENTAL_LOG_DATA(get_type_info, NONE);

  PROCEDURE get_type_info(
        schema                      IN     VARCHAR2,
        qname                       IN     VARCHAR2,
        gettds                      IN     BOOLEAN,
        rc                          OUT    BINARY_INTEGER,
        toid                        OUT    RAW,
        version                     OUT    NUMBER,
        tds                         OUT    LONG RAW);
  PRAGMA SUPPLEMENTAL_LOG_DATA(get_type_info, NONE);

  PROCEDURE verify_queue_types(
        src_queue_name  IN      VARCHAR2,
        dest_queue_name IN      VARCHAR2,
        destination     IN      VARCHAR2 DEFAULT NULL,
        rc              OUT     BINARY_INTEGER,
        transformation  IN      VARCHAR2 DEFAULT NULL);
  PRAGMA SUPPLEMENTAL_LOG_DATA(verify_queue_types, NONE);

  FUNCTION isShardedQueue(
        schema                       IN     VARCHAR2,
        qname                        IN     VARCHAR2) RETURN NUMBER ;

  PROCEDURE verify_sharded_queue (
                src_schema_name  IN      VARCHAR2,
                dest_queue_name IN      VARCHAR2,
                destination     IN      VARCHAR2,
                rc              OUT     NUMBER) ;

  PROCEDURE verify_queue_types_no_queue(
        src_queue_name  IN      VARCHAR2,
        dest_queue_name IN      VARCHAR2,
        destination     IN      VARCHAR2 DEFAULT NULL,
        rc              OUT     BINARY_INTEGER,
        transformation  IN      VARCHAR2 DEFAULT NULL);
  PRAGMA SUPPLEMENTAL_LOG_DATA(verify_queue_types_no_queue, NONE);

  PROCEDURE verify_queue_types_get_nrp(
        src_queue_name  IN      VARCHAR2,
        dest_queue_name IN      VARCHAR2,
        destination     IN      VARCHAR2 DEFAULT NULL,
        rc              OUT     BINARY_INTEGER,
        transformation  IN      VARCHAR2 DEFAULT NULL);
  PRAGMA SUPPLEMENTAL_LOG_DATA(verify_queue_types_get_nrp, NONE);

  PROCEDURE get_prop_seqno(qid    IN    NUMBER,
                           dqname IN    VARCHAR2,
                           dbname IN    VARCHAR2,
                           seq    OUT   BINARY_INTEGER);
  PRAGMA SUPPLEMENTAL_LOG_DATA(get_prop_seqno, NONE);

  PROCEDURE recover_propagation(
        schema          IN      VARCHAR2,
        queue_name      IN      VARCHAR2,
        destination     IN      VARCHAR2,
        protocol        IN      BINARY_INTEGER default TTC,
        url             IN      VARCHAR2 default NULL,
        username        IN      VARCHAR2 default NULL,
        passwd          IN      VARCHAR2 default NULL,
        trace           IN      BINARY_INTEGER default 0,
        destq           IN      BINARY_INTEGER default 0);
   PRAGMA SUPPLEMENTAL_LOG_DATA(recover_propagation, NONE);

  PROCEDURE schedule_propagation(
    queue_name                  IN     VARCHAR2,
    destination                 IN     VARCHAR2 DEFAULT NULL,
    start_time                  IN     TIMESTAMP WITH TIME ZONE DEFAULT NULL,
    duration                    IN     NUMBER DEFAULT NULL,
    next_time                   IN     VARCHAR2 DEFAULT NULL,
    latency                     IN     NUMBER DEFAULT 60,
    destination_queue           IN     VARCHAR2 DEFAULT NULL);
  PRAGMA SUPPLEMENTAL_LOG_DATA(schedule_propagation, NONE);

  PROCEDURE unschedule_propagation(
        queue_name                  IN     VARCHAR2,
        destination                 IN     VARCHAR2 DEFAULT NULL,
        destination_queue           IN     VARCHAR2 DEFAULT NULL);
  PRAGMA SUPPLEMENTAL_LOG_DATA(unschedule_propagation, NONE);

  PROCEDURE alter_propagation_schedule(
        queue_name                  IN     VARCHAR2,
        destination                 IN     VARCHAR2 DEFAULT NULL,
        duration                    IN     NUMBER DEFAULT NULL,
        next_time                   IN     VARCHAR2 DEFAULT NULL,
        latency                     IN     NUMBER DEFAULT 60,
        destination_queue           IN     VARCHAR2 DEFAULT NULL);
  PRAGMA SUPPLEMENTAL_LOG_DATA(alter_propagation_schedule, NONE);

  PROCEDURE enable_propagation_schedule(
        queue_name                  IN     VARCHAR2,
        destination                 IN     VARCHAR2 DEFAULT NULL,
        destination_queue           IN     VARCHAR2 DEFAULT NULL);
  PRAGMA SUPPLEMENTAL_LOG_DATA(enable_propagation_schedule, NONE);

  PROCEDURE disable_propagation_schedule(
        queue_name                  IN     VARCHAR2,
        destination                 IN     VARCHAR2 DEFAULT NULL,
        destination_queue           IN     VARCHAR2 DEFAULT NULL);
  PRAGMA SUPPLEMENTAL_LOG_DATA(disable_propagation_schedule, NONE);

  FUNCTION aq$_propaq(
        job                         IN     NUMBER) RETURN DATE;

  -- aq$_propaq is overloaded with 8.0.5 interface to facilitate
  -- upgrade/downgrade
  FUNCTION aq$_propaq(
        job                         IN     NUMBER,
        next_date                   IN     DATE,
        qname                       IN     VARCHAR2,
        schema                      IN     VARCHAR2,
        destination                 IN     VARCHAR2 DEFAULT NULL,
        toid_char                   IN     VARCHAR2 DEFAULT NULL,
        version_char                IN     VARCHAR2 DEFAULT NULL,
        start_time                  IN     VARCHAR2,
        duration                    IN     VARCHAR2 DEFAULT NULL,
        next_time                   IN     VARCHAR2 DEFAULT NULL,
        latency                     IN     VARCHAR2 DEFAULT '60') RETURN DATE;

  PROCEDURE start_time_manager;
  PRAGMA SUPPLEMENTAL_LOG_DATA(start_time_manager, NONE);

  PROCEDURE stop_time_manager;
  PRAGMA SUPPLEMENTAL_LOG_DATA(stop_time_manager, NONE);

  PROCEDURE migrate_queue_table(
         queue_table               IN      VARCHAR2,
         compatible                IN      VARCHAR2);
  PRAGMA SUPPLEMENTAL_LOG_DATA(migrate_queue_table, NONE);

  -- non-repudiate sender of ADT payload
  PROCEDURE nonrepudiate_sender(
         queue_name                IN      VARCHAR2,
         msgid                     IN      RAW,
         sender_info               IN      SYS.AQ$_AGENT,
         signature                 OUT     SYS.AQ$_SIG_PROP,
         payload                   OUT     "<ADT_1>");
  PRAGMA SUPPLEMENTAL_LOG_DATA(nonrepudiate_sender, NONE);

  -- non-repudiate sender of raw payload
  PROCEDURE nonrepudiate_sender(
         queue_name                IN      VARCHAR2,
         msgid                     IN      RAW,
         sender_info               IN      SYS.AQ$_AGENT,
         signature                 OUT     SYS.AQ$_SIG_PROP,
         payload                   OUT     raw);
  PRAGMA SUPPLEMENTAL_LOG_DATA(nonrepudiate_sender, NONE);

  PROCEDURE nonrepudiate_receiver(
         queue_name                IN      VARCHAR2,
         msgid                     IN      RAW,
         rcver_info                IN      SYS.AQ$_AGENT,
         signature                 OUT     SYS.AQ$_SIG_PROP,
         payload                   OUT     "<ADT_1>");
  PRAGMA SUPPLEMENTAL_LOG_DATA(nonrepudiate_receiver, NONE);

  PROCEDURE nonrepudiate_receiver(
         queue_name                IN      VARCHAR2,
         msgid                     IN      RAW,
         rcver_info                IN      SYS.AQ$_AGENT,
         signature                 OUT     SYS.AQ$_SIG_PROP,
         payload                   OUT     raw);
  PRAGMA SUPPLEMENTAL_LOG_DATA(nonrepudiate_receiver, NONE);

  PROCEDURE set_watermark(
         wmvalue                   IN      NUMBER);
  PRAGMA SUPPLEMENTAL_LOG_DATA(set_watermark, NONE);

  PROCEDURE get_watermark(
         wmvalue                   OUT     NUMBER);
  PRAGMA SUPPLEMENTAL_LOG_DATA(get_watermark, NONE);

  -- add an alias to LDAP
  PROCEDURE add_alias_to_ldap(
            alias               IN          VARCHAR2,
            obj_location        IN          VARCHAR2);
  PRAGMA SUPPLEMENTAL_LOG_DATA(add_alias_to_ldap, NONE);

  -- drop an alias from LDAP
  PROCEDURE del_alias_from_ldap(
            alias               IN          VARCHAR2);
  PRAGMA SUPPLEMENTAL_LOG_DATA(del_alias_from_ldap, NONE);

  -- AQ Authorization management procedures
  PROCEDURE create_aq_agent (
            agent_name                IN VARCHAR2,
            certificate_location      IN VARCHAR2 DEFAULT NULL,
            enable_http               IN BOOLEAN DEFAULT FALSE,
            enable_smtp               IN BOOLEAN DEFAULT FALSE,
            enable_anyp               IN BOOLEAN DEFAULT FALSE);
  PRAGMA SUPPLEMENTAL_LOG_DATA(create_aq_agent, AUTO);

  PROCEDURE alter_aq_agent(
            agent_name                IN VARCHAR2,
            certificate_location      IN VARCHAR2 DEFAULT NULL,
            enable_http               IN BOOLEAN DEFAULT FALSE,
            enable_smtp               IN BOOLEAN DEFAULT FALSE,
            enable_anyp               IN BOOLEAN DEFAULT FALSE);
  PRAGMA SUPPLEMENTAL_LOG_DATA(alter_aq_agent, AUTO);

  PROCEDURE drop_aq_agent (
            agent_name       IN VARCHAR2 );
  PRAGMA SUPPLEMENTAL_LOG_DATA(drop_aq_agent, AUTO);

  PROCEDURE enable_db_access (
            agent_name                IN VARCHAR2,
            db_username               IN VARCHAR2   );
  PRAGMA SUPPLEMENTAL_LOG_DATA(enable_db_access, AUTO);

  PROCEDURE disable_db_access (
            agent_name                IN VARCHAR2,
            db_username               IN VARCHAR2   );
  PRAGMA SUPPLEMENTAL_LOG_DATA(disable_db_access, AUTO);

  -- enable jms types IN anydata queue tables
  PROCEDURE enable_jms_types(
            queue_table          IN VARCHAR2);
  PRAGMA SUPPLEMENTAL_LOG_DATA(enable_jms_types, NONE);

  -- add a connection string to LDAP directory
  PROCEDURE add_connection_to_ldap(
            connection          IN       VARCHAR2,
            host                IN       VARCHAR2,
            port                IN       BINARY_INTEGER,
            sid                 IN       VARCHAR2,
            driver              IN       VARCHAR2 default NULL,
            type                IN       BINARY_INTEGER DEFAULT
                                         AQ_QUEUE_CONNECTION);
  PRAGMA SUPPLEMENTAL_LOG_DATA(add_connection_to_ldap, NONE);

  -- add a connection string to LDAP directory
  PROCEDURE add_connection_to_ldap(
            connection          IN       VARCHAR2,
            jdbc_string         IN       VARCHAR2,
            username            IN       VARCHAR2 default NULL,
            password            IN       VARCHAR2 default NULL,
            type                IN       BINARY_INTEGER DEFAULT
                                         AQ_QUEUE_CONNECTION);
  PRAGMA SUPPLEMENTAL_LOG_DATA(add_connection_to_ldap, NONE);

  -- drop a connection string from LDAP directory
  PROCEDURE del_connection_from_ldap(
            connection          IN          VARCHAR2);
  PRAGMA SUPPLEMENTAL_LOG_DATA(del_connection_from_ldap, NONE);

  -- purge queue table
  PROCEDURE purge_queue_table(
            queue_table         IN        VARCHAR2,
            purge_condition     IN        VARCHAR2,
            purge_options       IN        aq$_purge_options_t);
  PRAGMA SUPPLEMENTAL_LOG_DATA(purge_queue_table, NONE);

  -- get a sender's replay info
  PROCEDURE get_replay_info(
            queue_name               IN      VARCHAR2,
            sender_agent             IN      sys.aq$_agent,
            replay_attribute         IN      BINARY_INTEGER,
            correlation              OUT     VARCHAR2);
  PRAGMA SUPPLEMENTAL_LOG_DATA(get_replay_info, NONE);

  -- reset sender's replay info
  PROCEDURE reset_replay_info(
            queue_name               IN      VARCHAR2,
            sender_agent             IN      sys.aq$_agent,
            replay_attribute         IN      BINARY_INTEGER);
  PRAGMA SUPPLEMENTAL_LOG_DATA(reset_replay_info, NONE);

  -- Add procedures to set and get minimum/maximum AQ streams pool memory
  PROCEDURE set_min_streams_pool( value    IN    NUMBER);
  PROCEDURE set_max_streams_pool( value    IN    NUMBER);

  PROCEDURE get_min_streams_pool( value    OUT   NUMBER);
  PROCEDURE get_max_streams_pool( value    OUT   NUMBER);


END dbms_aqadm;
/

