create PACKAGE BODY dbms_xqueryint  AS

 FUNCTION prepare(xqry in varchar2,
              nlssrt in varchar2, nlscmp in varchar2, dbchr in varchar2, flags in number)  return number
   as LANGUAGE JAVA NAME
   'oracle.xquery.OXQServer.prepareQuery(java.lang.String,
         java.lang.String, java.lang.String, java.lang.String, int) return int';

 FUNCTION preparexclb(xqry in clob,
              nlssrt in varchar2, nlscmp in varchar2, dbchr in varchar2, flags in number)  return number
   as LANGUAGE JAVA NAME
   'oracle.xquery.OXQServer.prepareQuery(oracle.sql.CLOB,
         java.lang.String, java.lang.String, java.lang.String, int) return int';

 /*pass null for context binds. */
 procedure bind(hdl in number, name  in varchar2, flags  in number,
    xctx in clob, schema in varchar2)
  as LANGUAGE JAVA NAME
   'oracle.xquery.OXQServer.bind(int, java.lang.String, int, oracle.sql.CLOB,
     java.lang.String)';

  procedure bindWithType(hdl in number, name in varchar2, flags in number, xctx in clob, schema in varchar2 , xqtype in number)
  as LANGUAGE JAVA NAME
   'oracle.xquery.OXQServer.bindWithType(int, java.lang.String, int,
     oracle.sql.CLOB,
     java.lang.String, int)';

 FUNCTION fetchOne(hdl in number, xctx in out clob, flags in out number,
     str out varchar2, xqtype in out number) return number as LANGUAGE JAVA NAME
   'oracle.xquery.OXQServer.fetchOne(int, oracle.sql.CLOB[], int[],
     java.lang.String[], int[]) return int';

 FUNCTION fetchAll(hdl in number, xctx in out clob, flags in out number)
   return number
      as LANGUAGE JAVA NAME
   'oracle.xquery.OXQServer.fetchAll(int, oracle.sql.CLOB[], int[]) return int';

 procedure execQuery(hdl in number) as LANGUAGE JAVA NAME
   'oracle.xquery.OXQServer.execute(int)' ;

 procedure closeHdl(hdl in number) as LANGUAGE JAVA NAME
   'oracle.xquery.OXQServer.closeHdl(int)' ;

 /* return xmltype(content) */
 FUNCTION exec_cont(hdl in number) return sys.xmltype is
    clb clob := ' ';
   ret xmltype := null;
   outflg number := 0;
   fetch_ok number ;
 begin

   fetch_ok := fetchAll(hdl, clb, outflg);

   if  fetch_ok >= 1 then
     if outflg  = QMXQRS_JAVA_FRAGMENT then
       ret :=
       xmltype.createxml('<A>'||  clb || '</A>',null,1,1).extract('/A/node()');
     else
        ret :=  xmltype.createxml(clb, null, 1,1);
     end if;
   end if;

    /* we cache the xquery plan in qmxqrs.c level, so we don't close the
     * handle ourselves, instead, replying on qmxqrs.c to call plan close
     */
   /*closeHdl(hdl);*/
   return ret;

 end;

 /* return a sequence */
 FUNCTION exec_seq(hdl in number) return sys.xmltype is
  fetch_ok number;
  str varchar2(4000);
  clb clob := ' ';
   xval xmltype;
   ret xmltype := null;
  outflg number := 0;
  xqtype number := QMTXT_INVALIDTYPE;
  noDocWrap number := 0;
 begin

   loop

     /* initialize loop variables */
     outflg := 0;
     xqtype := QMTXT_INVALIDTYPE;
     noDocWrap := 0;

     fetch_ok := fetchOne(hdl, clb, outflg, str, xqtype);
     if  fetch_ok = 0 then exit; end if;

     if  str is not null then
       /* sync with OXQServerJava.getOutAtomicType() */
       /*
       dbms_output.put_line('xqtype = ' || to_char(xqtype));
       dbms_output.put_line('outflg = ' || to_char(outflg));
       */
       if xqtype = QMTXT_STRING then
         /*DTYCHR; QMTXT_STRING;*/
         select SYS_XQ_PKSQL2XML(str, 1, 2) into xval from sys.dual;
       elsif xqtype =  QMTXT_DECIMAL then
         /*DTYNUM; QMTXT_DECIMAL;*/
         select SYS_XQ_PKSQL2XML(to_number(str), 2, 4) into xval from sys.dual;
       elsif xqtype =  QMTXT_INTEGER then
         /*DTYNUM; QMTXT_INTEGER;*/
         select SYS_XQ_PKSQL2XML(to_number(str), 2, 33) into xval from sys.dual;
       elsif xqtype =  QMTXT_DATE then
         /*DTYSTZ; QMTXT_DATE;*/
         select SYS_XQ_PKSQL2XML(SYS_XMLCONV(str,3,10,0,0,181), 181, 10)
         into xval
         from sys.dual;
       elsif xqtype =  QMTXT_TIME then
         /*DTYSTZ; QMTXT_TIME;*/
         select SYS_XQ_PKSQL2XML(SYS_XMLCONV(str,3,9,0,0,181), 181, 9)
         into xval
         from sys.dual;
       elsif xqtype =  QMTXT_DATETIME then
         /*DTYSTZ; QMTXT_DATETIME;*/
         select SYS_XQ_PKSQL2XML(SYS_XMLCONV(str,3,8,0,0,181), 181, 8)
         into xval
         from sys.dual;
       elsif xqtype =  QMTXT_FLOAT then
         /*DTYIBFLOAT; QMTXT_FLOAT;*/
         select SYS_XQ_PKSQL2XML(to_binary_float(str), 100, 5) into xval from sys.dual;
       elsif xqtype =  QMTXT_DOUBLE then
         /*DTYIBDOUBLE; QMTXT_DOUBLE;*/
         select SYS_XQ_PKSQL2XML(to_binary_double(str), 101, 6) into xval from sys.dual;
        elsif xqtype =  QMTXT_XDT_YEARMONTHDURATION then
         /*DTYEIYM; QMTXT_XDT_YEARMONTHDURATION;*/
         select SYS_XQ_PKSQL2XML(SYS_XMLCONV(str,3,52,0,0,189), 189, 52) into xval from sys.dual;
        elsif xqtype =  QMTXT_XDT_DAYTIMEDURATION then
         /*DTYEIDS; QMTXT_XDT_DAYTIMEDURATION;*/
         select SYS_XQ_PKSQL2XML(SYS_XMLCONV(str,3,51,0,0,190), 190, 51) into xval from sys.dual;
        elsif xqtype =  QMTXT_BOOLEAN then
         /*DTYBIN; QMTXT_BOOLEAN;*/
         select SYS_XQ_PKSQL2XML(case SYS_XQ_ATOMCNVCHK(str,1,3) WHEN '0' THEN HEXTORAW('00')  ELSE HEXTORAW('01')  END, 23, 3) into xval from sys.dual;
        elsif xqtype =  QMTXT_GDAY then
         /*DTYSTZ; QMTXT_GDAY;*/
         select SYS_XQ_PKSQL2XML(SYS_XMLCONV(str,3,11,0,0,181), 181, 11) into xval from sys.dual;
        elsif xqtype =  QMTXT_GMONTH then
         /*DTYSTZ; QMTXT_GMONTH;*/
         select SYS_XQ_PKSQL2XML(SYS_XMLCONV(str,3,12,0,0,181), 181, 12) into xval from sys.dual;
        elsif xqtype =  QMTXT_GYEAR then
         /*DTYSTZ; QMTXT_GYEAR;*/
         select SYS_XQ_PKSQL2XML(SYS_XMLCONV(str,3,13,0,0,181), 181, 13) into xval from sys.dual;
        elsif xqtype =  QMTXT_GYEARMONTH then
         /*DTYSTZ; QMTXT_GYEARMONTH;*/
         select SYS_XQ_PKSQL2XML(SYS_XMLCONV(str,3,14,0,0,181), 181, 14) into xval from sys.dual;
        elsif xqtype =  QMTXT_GMONTHDAY then
         /*DTYSTZ; QMTXT_GMONTHDAY;*/
         select SYS_XQ_PKSQL2XML(SYS_XMLCONV(str,3,15,0,0,181), 181, 15) into xval from sys.dual;
        elsif xqtype =  QMTXT_DURATION then
         /*DTYCHR; QMTXT_DURATION;*/
         select SYS_XQ_PKSQL2XML(str, 1,7) into xval from sys.dual;
        elsif xqtype =  QMTXT_XDT_UNTYPEDATOMIC then
         /*DTYCHR; QMTXT_XDT_UNTYPEDATOMIC;*/
         select SYS_XQ_PKSQL2XML(str, 1,50) into xval from sys.dual;
        elsif xqtype =  QMTXT_BASE64BINARY  then
         /*DTYBIN; QMTXT_BASE64BINARY ;*/
         select SYS_XQ_PKSQL2XML(SYS_XMLCONV(str,3,17,0,0,23), 23, 17) into xval from sys.dual;
        elsif xqtype =  QMTXT_HEXBINARY  then
         /*DTYBIN; QMTXT_HEXBINARY ;*/
         select SYS_XQ_PKSQL2XML(HEXTORAW(str), 23, 16) into xval from sys.dual;
        elsif xqtype =  QMTXT_NONPOSITIVEINTEGER  then
         /*DTYNUM; QMTXT_NONPOSITIVEINTEGER ;*/
         select SYS_XQ_PKSQL2XML(SYS_XQ_ATOMCNVCHK(to_number(str),2,34), 2, 34) into xval from sys.dual;
        elsif xqtype =  QMTXT_NEGATIVEINTEGER  then
         /*DTYNUM; QMTXT_NEGATIVEINTEGER ;*/
         select SYS_XQ_PKSQL2XML(SYS_XQ_ATOMCNVCHK(to_number(str),2,35), 2, 35) into xval from sys.dual;
        elsif xqtype =  QMTXT_LONG  then
         /*DTYNUM; QMTXT_LONG ;*/
         select SYS_XQ_PKSQL2XML(SYS_XQ_ATOMCNVCHK(to_number(str),2,36), 2, 36) into xval from sys.dual;
        elsif xqtype =  QMTXT_INT  then
         /*DTYNUM; QMTXT_POSITIVEINTEGER ;*/
         select SYS_XQ_PKSQL2XML(SYS_XQ_ATOMCNVCHK(to_number(str),2,37), 2, 37) into xval from sys.dual;
        elsif xqtype =  QMTXT_SHORT  then
         /*DTYNUM; QMTXT_SHORT ;*/
         select SYS_XQ_PKSQL2XML(SYS_XQ_ATOMCNVCHK(to_number(str),2,38), 2, 38) into xval from sys.dual;
        elsif xqtype =  QMTXT_BYTE  then
         /*DTYNUM; QMTXT_BYTE ;*/
         select SYS_XQ_PKSQL2XML(SYS_XQ_ATOMCNVCHK(to_number(str),2,39), 2, 39) into xval from sys.dual;
        elsif xqtype =  QMTXT_NONNEGATIVEINTEGER  then
         /*DTYNUM; QMTXT_NONNEGATIVEINTEGER ;*/
         select SYS_XQ_PKSQL2XML(SYS_XQ_ATOMCNVCHK(to_number(str),2,40), 2, 40) into xval from sys.dual;
        elsif xqtype =  QMTXT_UNSIGNEDLONG  then
         /*DTYNUM; UNSIGNEDLONG ;*/
         select SYS_XQ_PKSQL2XML(SYS_XQ_ATOMCNVCHK(to_number(str),2,41), 2, 41) into xval from sys.dual;
        elsif xqtype =  QMTXT_UNSIGNEDINT  then
         /*DTYNUM; UNSIGNEDINT ;*/
         select SYS_XQ_PKSQL2XML(SYS_XQ_ATOMCNVCHK(to_number(str),2,42), 2, 42) into xval from sys.dual;
        elsif xqtype =  QMTXT_UNSIGNEDSHORT  then
         /*DTYNUM; UNSIGNEDSHORT ;*/
         select SYS_XQ_PKSQL2XML(SYS_XQ_ATOMCNVCHK(to_number(str),2,43), 2, 43) into xval from sys.dual;
        elsif xqtype =  QMTXT_UNSIGNEDBYTE  then
         /*DTYNUM; UNSIGNEDBYTE ;*/
         select SYS_XQ_PKSQL2XML(SYS_XQ_ATOMCNVCHK(to_number(str),2,44), 2, 44) into xval from sys.dual;
        elsif xqtype =  QMTXT_POSITIVEINTEGER  then
         /*DTYNUM; QMTXT_POSITIVEINTEGER ;*/
         select SYS_XQ_PKSQL2XML(SYS_XQ_ATOMCNVCHK(to_number(str),2,45), 2, 45) into xval from sys.dual;
       else
         /*DTYCHR; QMTXT_STRING;*/
         select SYS_XQ_PKSQL2XML(str, 1, 2) into xval from sys.dual;
       end if;
     else
       if bitand(outflg, QMXQRS_JAVA_NO_DOCWRAP) = QMXQRS_JAVA_NO_DOCWRAP then
         noDocWrap := 1;
       end if;
       if bitand(outflg, QMXQRS_JAVA_FRAGMENT) = QMXQRS_JAVA_FRAGMENT then
         /* This make pi , comment, text, attribute node to go through this,
          * however, attribute node can not survive from /A/node() as it
          * becomes text node, we need standalone attribute node tran to
          * handle this. For these case, however, noDocWrap = 1 and
          * sys_xqcon2seq() call below will make it turn on NO_DOCWRAP flag.
          * Also, for the case of xquery DM node constructed from
          * document {} constructor, the xquery java engine uses
          * DOM QMXQRS_JAVA_FRAGMENT node to represent this, however, the
          * noDocWrap =0 in this case and xmltype.extract() returning content
          * which has NO NO_DOCWRAP flag on, which is right for this case.
          */
         xval :=
          xmltype.createxml('<A>'||clb ||'</A>',null,1,1).extract('/A/node()');
         /*
          select extract(xmltype.createxml('<A>'||clb ||'</A>',null,1,1),'/A/node()') into xval
          from sys.dual;
         */
       else
         /* only document node or single element node goes to here */
         xval := xmltype.createxml(clb,null,1,1);
       end if;
       clb := ' ';
     end if;

     /*dbms_output.put_line('noDocWrap = ' || to_char(noDocWrap));*/
     if (noDocWrap = 1) then
       /* turn on NO_DOCWRAP flag in the image for node without document node
        * wrapper.
        */
       select sys_xqcon2seq(xval) into xval from sys.dual;
     end if;

     select sys_xqconcat(ret, xval) into ret from sys.dual;

   end loop;

    /* we cache the xquery plan in qmxqrs.c level, so we don't close the
     * handle ourselves, instead, replying on qmxqrs.c to call plan close
     */
   /*closeHdl(hdl); */
   return ret;
 end;

 /* for XMLEXISTS(), we just want to make sure result is NOT empty sequnce*/
 FUNCTION exec_exists(hdl in number, retseq in number) return number is
  fetch_ok number;
  str varchar2(4000);
  clb clob := ' ';
  xval xmltype;
  ret number := 0;
  outflg number := QMXQRS_JAVA_CHK_EXSTS; /* pass on flag for XMLEXISTS check*/
  xqtype number := 0;
 begin


     fetch_ok := fetchOne(hdl, clb, outflg, str, xqtype);
     if  fetch_ok = 0 then
      ret := 0;
     else
       ret := 1;
     end if;

    /* we cache the xquery plan in qmxqrs.c level, so we don't close the
     * handle ourselves, instead, replying on qmxqrs.c to call plan close
     */
   /*closeHdl(hdl);*/
   return ret;
 end;

 FUNCTION exec(hdl in number, retseq in number)
  return sys.xmltype is
 begin
   if retseq = 1 then
     return exec_seq(hdl);
   else
     return exec_cont(hdl);
   end if;
 end;

 FUNCTION getXQueryX(xqry in varchar2)  return clob  as LANGUAGE JAVA NAME
 'oracle.xquery.OXQServer.getXQueryX(java.lang.String) return oracle.sql.CLOB';

 FUNCTION getXQueryXxclb(xqry in clob)  return clob  as LANGUAGE JAVA NAME
 'oracle.xquery.OXQServer.getXQueryX(oracle.sql.CLOB) return oracle.sql.CLOB';

 FUNCTION execallCmn(xqry in varchar2,  nlssrt in varchar2, nlscmp in varchar2,
        dbchr in varchar2, retseq in number, flags in number, xqryclb in clob,
        xqisclob in number, hdl in out number)
  return sys.xmltype is
    --hdl number;
 begin
  if (hdl = 0) then
    /* xquery plan has not been built, so let's build it */
    if xqisclob = 1 then
      hdl := preparexclb(xqryclb, nlssrt, nlscmp, dbchr, flags);
    else
      hdl := prepare(xqry, nlssrt, nlscmp, dbchr, flags);
    end if;
  end if;

  execQuery(hdl);
  return exec(hdl, retseq);
 end;

 FUNCTION execallCmn_exists(xqry in varchar2,  nlssrt in varchar2,
        nlscmp in varchar2,
        dbchr in varchar2, retseq in number, flags in number, xqryclb in clob,
        xqisclob in number, hdl in out number)
  return number is
    --hdl number;
 begin
  if (hdl = 0) then
    /* xquery plan has not been built, so let's build it */
    if xqisclob = 1 then
      hdl := preparexclb(xqryclb, nlssrt, nlscmp, dbchr, flags);
    else
      hdl := prepare(xqry, nlssrt, nlscmp, dbchr, flags);
    end if;
  end if;

  execQuery(hdl);
  return exec_exists(hdl, retseq);
 end;

 FUNCTION execall(xqry in varchar2,  nlssrt in varchar2, nlscmp in varchar2,
        dbchr in varchar2, retseq in number, flags in number, hdl in out number)
  return sys.xmltype is
  begin
    return execallCmn(xqry, nlssrt, nlscmp, dbchr, retseq, flags, null, 0, hdl);
  end;

 FUNCTION execallxclb(xqryclb in clob,  nlssrt in varchar2, nlscmp in varchar2,
        dbchr in varchar2, retseq in number, flags in number, hdl in out number)
  return sys.xmltype parallel_enable is
  begin
    return execallCmn(null, nlssrt, nlscmp, dbchr, retseq, flags, xqryclb, 1, hdl);
  end;

 FUNCTION execall_exists(xqry in varchar2,  nlssrt in varchar2,
        nlscmp in varchar2,
        dbchr in varchar2, retseq in number, flags in number,
        hdl in out number)
  return number is
  begin
    return execallCmn_exists(xqry, nlssrt, nlscmp, dbchr, retseq, flags, null, 0, hdl);
  end;

 FUNCTION execallxclb_exists(xqryclb in clob,  nlssrt in varchar2,
        nlscmp in varchar2,
        dbchr in varchar2, retseq in number, flags in number,
        hdl in out number)
  return number is
  begin
    return execallCmn_exists(null, nlssrt, nlscmp, dbchr, retseq, flags, xqryclb, 1, hdl);
  end;

 /* testing function */
 FUNCTION executeCmn(xqry in varchar2, xctx in xmltype:=null, retseq in number := 0, xqryclb in clob, xqisclob in number)
  return sys.xmltype  parallel_enable is
   a number := 0;
   dbchr varchar2(30);
   nlscmp varchar2(30);
   nlssrt varchar2(30);
   hdl number;
 begin

  select value into dbchr from "PUBLIC".v$nls_parameters where
      parameter = 'NLS_CHARACTERSET';
  select value into nlssrt from "PUBLIC".v$nls_parameters where
      parameter = 'NLS_SORT';
  select value into nlscmp from "PUBLIC".v$nls_parameters where
      parameter = 'NLS_COMP';

   if xqisclob = 1 then
     hdl := preparexclb(xqryclb, nlssrt, nlscmp, dbchr, 0);
   else
     hdl := prepare(xqry, nlssrt, nlscmp, dbchr, 0);
   end if;

   if xctx is not null then
      if xctx.isFragment() = 1 then
        a := QMXQRS_JAVA_FRAGMENT;
      end if;
      bind(hdl, null, a, xctx.getclobval(), xctx.getSchemaURL());
   end if;

  execQuery(hdl);
  return exec(hdl, retseq);

 end;

 FUNCTION execute(xqry in varchar2, xctx in xmltype:=null, retseq in number := 0)
  return sys.xmltype  parallel_enable is
  begin
   return  executeCmn(xqry, xctx, retseq, null, 0);
  end;

 function executexclb(xqry in clob, xctx in xmltype := null,
                  retseq in number := 0)
   return sys.xmltype parallel_enable is
  begin
   return  executeCmn(null, xctx, retseq, xqry, 1);
  end;

end;
/

