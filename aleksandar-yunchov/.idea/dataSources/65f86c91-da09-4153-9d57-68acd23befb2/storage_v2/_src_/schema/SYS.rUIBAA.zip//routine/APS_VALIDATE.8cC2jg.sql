create PROCEDURE aps_validate IS
   AWok BOOLEAN;
   OBJok BOOLEAN;
   x NUMBER; -- dummy output spot
   junklob CLOB;
   v_Value varchar2(64);
   running BOOLEAN;
   stmt VARCHAR2(100);
   e_level BINARY_INTEGER;
   new_e_level BINARY_INTEGER;
BEGIN

   -- get current event level
    sys.dbms_system.read_ev(37396, e_level);
    select e_level + 2048 - bitand(e_level, 2048) into new_e_level from dual;
    EXECUTE IMMEDIATE 'alter session set events=''37396 trace name context forever,  level '||to_char(new_e_level)||'''';

   if sys.dbms_aw.olap_running() then
     running := TRUE;
   else
     running := FALSE;
   end if;
   -- AWs are valid if we can read an option
   BEGIN
     junklob := sys.dbms_aw.INTERP('show SESSCACHE');
     AWok := TRUE;
   EXCEPTION
     WHEN OTHERS THEN
       AWok := FALSE;
   END;

   -- supporting object things
   BEGIN
     SELECT 0 INTO x FROM DBA_OBJECTS
       WHERE STATUS = 'INVALID' AND rownum <=1 AND
         OWNER='SYS' AND OBJECT_NAME IN
        ('OLAP_TABLE', 'OLAPIMPL_T', 'OLAP_SRF_T', 'OLAP_NUMBER_SRF',
         'OLAP_EXPRESSION', 'OLAP_TEXT_SRF', 'OLAP_EXPRESSION_TEXT',
         'OLAP_BOOL_SRF', 'OLAP_EXPRESSION_BOOL');
     -- at least one object is invalid so component is invalid
     OBJok := FALSE;
   EXCEPTION
   WHEN NO_DATA_FOUND THEN
     -- no invalid objects were found so component is valid
     OBJok := TRUE;
   END;

   IF NOT running THEN
      sys.dbms_aw.shutdown(TRUE);
   END IF;
   stmt := 'alter SESSION SET EVENTS ''37396 trace name context off''';
   execute immediate stmt;
   IF AWok AND OBJok THEN
     SELECT value INTO v_Value FROM v$option WHERE parameter = 'OLAP';
     if v_Value = 'FALSE' then
       sys.dbms_registry.Option_Off('APS');
     else
       sys.dbms_registry.valid('APS');
     end if;
   ELSE
     sys.dbms_registry.invalid('APS');
   END IF;
   EXCEPTION
   WHEN OTHERS THEN
     execute immediate 'ALTER SESSION SET EVENTS ''37396 trace name context level to_char(e_level)''';
     raise;
  END;
/

