create PACKAGE dbms_crypto_toolkit_types AS

    SUBTYPE Crypto_Engine_Function IS POSITIVE;

    SUBTYPE Crypto_Engine_State IS POSITIVE;

    SUBTYPE Identity_Type IS POSITIVE;

    SUBTYPE Cipher IS POSITIVE;

    SUBTYPE Data_Unit_Format IS POSITIVE;

    ------------------------- OPAQUE DATA TYPES ------------------------------
    -- These data types are intended to be opaque. The contents of the records
    -- are either not visible to the caller or are to be accessed using
    -- convenience functions. Unfortunately, PL/SQL does not allow type
    -- definitions to be hidden inside the package bodies.

    -- Records are used in order to enforce type checking as PL/SQL will
    -- otherwise do automatic type conversion.

    -- Dummy variables are used to get around PL/SQL restriction which does not
    -- allow constrained subtypes, e.g. SUBTYPE foo is VARCHAR(15) is not
    -- allowed.

    wallet_size RAW(200);
    SUBTYPE Wallet_Internal IS wallet_size%TYPE;
    TYPE Wallet IS RECORD
        (Wallet Wallet_Internal
        );

    persona_internal_size RAW(200);
    SUBTYPE Persona_Internal IS persona_internal_size%TYPE;
    TYPE Persona IS RECORD
        (Persona Persona_Internal
        );

    identity_internal_size RAW(200);
    SUBTYPE Identity_Internal IS identity_internal_size%TYPE;
    TYPE Identity IS RECORD
        (Descriptor Identity_Internal
        );

    identity_array_internal_size RAW(200);
    SUBTYPE Identity_Array_Internal IS identity_array_internal_size%TYPE;
    TYPE Identity_Array IS RECORD
        (Descriptor_Array Identity_Array_Internal
        );

    -------------------------- DATA STRUCTURES --------------------------------
    alias_string_length VARCHAR2(512);
    SUBTYPE Alias_String IS alias_string_length%TYPE;

    comment_string_length VARCHAR2(512);
    SUBTYPE Comment_String IS comment_string_length%TYPE;

    -- This data structure describes an identity. An identity may either
    -- myself (a persona) or another trusted identity
    TYPE Identity_Description IS RECORD
        (alias   Alias_String,
         comment Comment_String
        );

    -- This table serves as list of the retrieved identity descriptions.
    TYPE Identity_Description_List IS TABLE OF
        Identity_Description
        INDEX BY BINARY_INTEGER;

    -- This record contains the printable alias for a persona as well as the
    -- complete identity and persona.
    -- NOTE: the size of the persona field must match that contained within
    --       the Persona type. PL/SQL will not allow a record to
    --       contain another record so the Persona could not be used
    --       directly.
    TYPE Persona_Description IS RECORD
        (alias    Alias_String,
         comment  Comment_String,
         identity Identity_Internal,
         persona  Persona_Internal
        );

    TYPE Persona_List IS TABLE OF
        Persona_Description
        INDEX BY BINARY_INTEGER;

    -- This data structure is a place holder until it is determined what
    -- private information is needed to create a persona.
    Private_Persona_Info_Size RAW(200);
    SUBTYPE Private_Persona_Info_Internal IS Private_Persona_Info_Size%TYPE;
    TYPE Private_Persona_Information is RECORD
        (information Private_Persona_Info_Internal
        );

END dbms_crypto_toolkit_types;
/

