create type aq$_jms_object_message
                                      
as object
(
  header     aq$_jms_header,
  bytes_len  int,
  bytes_raw  raw(2000),
  bytes_lob  blob
);
/

