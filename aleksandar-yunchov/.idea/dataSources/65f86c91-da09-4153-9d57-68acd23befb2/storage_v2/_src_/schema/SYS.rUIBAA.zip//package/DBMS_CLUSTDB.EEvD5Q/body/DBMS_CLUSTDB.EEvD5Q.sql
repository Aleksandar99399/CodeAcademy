create PACKAGE BODY dbms_clustdb AS

----------------------------------------------------------------------
-- PUBLIC FUNCTIONS
----------------------------------------------------------------------

PROCEDURE validate IS
start_time DATE;
end_time   DATE;
option_val VARCHAR2(64);
g_null     CHAR(1);
BEGIN

   BEGIN
      SELECT null INTO g_null FROM obj$ o, user$ u
         WHERE o.owner#=u.user# AND u.name = 'PUBLIC'
               AND o.name='GV$GES_STATISTICS';
--    valid if gv$ges_statistics exists;
      SELECT value INTO option_val FROM v$option
         WHERE parameter = 'Real Application Clusters';
--    check if RAC option has been linked in
      IF option_val = 'TRUE' THEN
         dbms_registry.valid('RAC');
      ELSE
         update registry$ set status = 9 where cid='RAC';
         commit;
      END IF;
   EXCEPTION
      WHEN NO_DATA_FOUND THEN
      dbms_registry.invalid('RAC');
   END;
END validate;

END dbms_clustdb;
/

