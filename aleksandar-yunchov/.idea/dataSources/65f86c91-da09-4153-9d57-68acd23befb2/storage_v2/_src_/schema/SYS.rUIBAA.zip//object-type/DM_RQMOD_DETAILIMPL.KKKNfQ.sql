create TYPE dm$rqMod_DetailImpl
AUTHID CURRENT_USER AS OBJECT (
  typ                            SYS.AnyType,
  key                            RAW(4),

  -- ODCITableDescribe --------------------------------------------------------
  --
  STATIC FUNCTION ODCITableDescribe(
    typ1                           OUT SYS.AnyType,
    mod_nam                        VARCHAR2,
    par_cur                        SYS_REFCURSOR,
    out_qry                        VARCHAR2,
    view_num                       NUMBER default -1)
  RETURN PLS_INTEGER,

  STATIC FUNCTION StubTableDescribe(
    typ1                           OUT SYS.AnyType,
    par_cur                        SYS_REFCURSOR,
    out_qry                        VARCHAR2,
    exp_nam                        VARCHAR2)
  RETURN PLS_INTEGER,

  -- ODCITablePrepare ---------------------------------------------------------
  --
  STATIC FUNCTION ODCITablePrepare(
    sctx                           OUT dm$rqMod_DetailImpl,
    tf_info                        SYS.ODCITabFuncInfo,
    mod_nam                        VARCHAR2,
    par_cur                        SYS_REFCURSOR,
    out_qry                        VARCHAR2,
    view_num                       NUMBER default -1)
  RETURN PLS_INTEGER,

  STATIC FUNCTION StubTablePrepare(
    sctx                           OUT dm$rqMod_DetailImpl,
    tf_info                        SYS.ODCITabFuncInfo,
    par_cur                        SYS_REFCURSOR,
    out_qry                        VARCHAR2,
    exp_nam                        VARCHAR2)
  RETURN PLS_INTEGER,

  -- ODCITableStart -----------------------------------------------------------
  --
  STATIC FUNCTION ODCITableStart(
    sctx                           IN OUT dm$rqMod_DetailImpl,
    mod_nam                        VARCHAR2,
    par_cur                        SYS_REFCURSOR,
    out_qry                        VARCHAR2,
    view_num                       NUMBER default -1)
  RETURN PLS_INTEGER,

  STATIC FUNCTION StubTableStart(
    sctx                           IN OUT dm$rqMod_DetailImpl,
    mod_cur                        SYS_REFCURSOR,
    par_cur                        SYS_REFCURSOR,
    out_qry                        VARCHAR2,
    env_val                        ora_mining_varchar2_nt,
    exp_nam                        VARCHAR2)
  RETURN PLS_INTEGER,

  -- ODCITableFetch -----------------------------------------------------------
  --
  MEMBER FUNCTION ODCITableFetch(
    self                           IN OUT dm$rqMod_DetailImpl,
    nrows                          NUMBER,
    rws                            OUT SYS.AnyDataSet)
  RETURN PLS_INTEGER,

  MEMBER FUNCTION StubTableFetch(
    self                           IN OUT dm$rqMod_DetailImpl,
    nrows                          NUMBER,
    rws                            OUT SYS.AnyDataSet)
  RETURN PLS_INTEGER,

  -- ODCITableClose -----------------------------------------------------------
  --
  MEMBER FUNCTION ODCITableClose(
    self                           dm$rqMod_DetailImpl)
  RETURN PLS_INTEGER,

  MEMBER FUNCTION StubTableClose(
    self                           dm$rqMod_DetailImpl)
  RETURN PLS_INTEGER
);
/

