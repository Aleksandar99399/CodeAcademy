create type dm_em_component
                                       as object
  (info_type             VARCHAR2(30)
  ,component_id          NUMBER
  ,cluster_id            NUMBER
  ,attribute_name        VARCHAR2(4000)
  ,covariate_name        VARCHAR2(4000)
  ,attribute_value       VARCHAR2(4000)
  ,value                 NUMBER
  )
/

