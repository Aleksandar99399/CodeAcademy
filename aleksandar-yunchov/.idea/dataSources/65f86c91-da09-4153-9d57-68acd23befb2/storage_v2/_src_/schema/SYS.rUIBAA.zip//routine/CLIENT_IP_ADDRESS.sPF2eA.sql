create function client_ip_address
return varchar2 is
begin
return dbms_standard.client_ip_address;
end;
/

