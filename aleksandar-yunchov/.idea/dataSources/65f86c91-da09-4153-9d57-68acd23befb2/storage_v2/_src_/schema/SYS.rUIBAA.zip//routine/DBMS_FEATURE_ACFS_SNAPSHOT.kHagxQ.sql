create PROCEDURE dbms_feature_acfs_snapshot
      (is_used OUT number, aux_count OUT number, feature_info OUT clob)
AS
BEGIN
  /* Query to detect if ACFS snapshot are being used */
  select count(*) into is_used from gv$asm_acfssnapshots;

   -- compose the CLOB
   feature_info := ':num_snapshots: '||is_used;
END;
/

