create procedure DBMS_FEATURE_ILM
    (feature_boolean  OUT  NUMBER,
     aux_count        OUT  NUMBER,
     feature_info     OUT  CLOB)
AS
    feature_usage         varchar2(1000);
    num_ilm_pol           number := 0;
    num_obj_pol           number := 0;
begin
    -- initialize
    feature_boolean := 0;
    aux_count       := 0;
    feature_info    := to_clob('Information Lifecycle Management not detected');

    -- check for ILM usage by counting policies in ILM dictionary
    execute immediate 'select count(*) from ilm$ '
       into num_ilm_pol;

    if num_ilm_pol > 0 then

      feature_boolean := 1;

      execute immediate 'select count(*) from ilmobj$ '
         into num_obj_pol;

      feature_usage   :=
                'Number of ILM Policies: ' || to_char(num_ilm_pol) ||
        ', ' || 'Number of Objects Affected: ' || to_char(num_obj_pol);
      feature_info    := to_clob(feature_usage);

    end if;

end;
/

