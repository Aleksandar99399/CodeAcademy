create TYPE COLHISTREC FORCE AS OBJECT(
    cind    integer,                    -- index into CRec structure
    bval    integer,                    -- bucket value
    edval   varchar2(240),              -- endpoint dump value
    enval   number,                     -- endpoint normalized value
    eaval   raw(64),                    -- endpoint actual value
    maxrep  number                      -- used to build freq hisotgrams
);
/

