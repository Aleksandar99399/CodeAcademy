create TYPE adr_incident_corr_key_t FORCE AS OBJECT
(
  name                  VARCHAR2(64),                /* correlation key name */
  value                 VARCHAR2(512),               /* correlation key value*/
  flags                 INTEGER                     /* correlation key flags */
);
/

