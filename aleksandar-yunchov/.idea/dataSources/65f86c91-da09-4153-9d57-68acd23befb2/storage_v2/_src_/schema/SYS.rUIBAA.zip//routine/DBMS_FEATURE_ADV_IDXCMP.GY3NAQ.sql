create procedure DBMS_FEATURE_ADV_IDXCMP(
    feature_boolean OUT NUMBER,
    aux_count       OUT NUMBER,
    feature_info    OUT CLOB)
AS
    feature_usage               varchar2(1000);
    oltp_high_idx_cnt           number;
    oltp_low_idx_cnt            number;
    oltp_high_part_idx_cnt      number;
    oltp_low_part_idx_cnt       number;
    num_oltp_high               number;
    num_oltp_low                number;
    blk_oltp_high               number;
    blk_oltp_low                number;
    def_oltp_high               number;
    def_oltp_low                number;
    tmp_pattern                 varchar(50);

BEGIN
    feature_boolean             := 0;
    aux_count                   := 0;
    --Pattern used by Compression Advisor for creating temporary
    --compressed objects
    tmp_pattern                 := '''' ||
                                   prvt_compression.COMP_TMP_OBJ_PREFIX ||
                                   '%''';

    --Check for ADVANCED HIGH seg, block, deferred seg
    execute immediate 'select count(*) from seg$ s, ind$ i, obj$ o ' ||
      ' where s.type# = 6 AND ' ||
            ' s.user# not in (select user# from user$ ' ||
                ' where name in (''SYS'' , ''SYSTEM'' )) AND ' ||
            ' bitand(s.spare1, 2048) = 2048 AND ' ||
            ' bitand(s.spare1, 16777216 + 1048576) = 16777216 AND ' ||
            ' s.ts# = i.ts# AND s.file# = i.file# AND ' ||
            ' s.block# = i.block# AND i.obj# = o.obj# AND ' ||
            ' o.name not like ' || tmp_pattern
      into num_oltp_high;

    if (num_oltp_high = 0) then
      blk_oltp_high := 0;
    else
      execute immediate 'select sum(blocks) from seg$ s, ind$ i, obj$ o ' ||
        ' where s.type# = 6 AND ' ||
              ' s.user# not in (select user# from user$ ' ||
                  ' where name in (''SYS'', ''SYSTEM'' )) AND' ||
              ' bitand(s.spare1, 2048) = 2048 AND ' ||
              ' bitand(s.spare1, 16777216 + 1048576) = 16777216 AND ' ||
              ' s.ts# = i.ts# AND s.file# = i.file# AND ' ||
              ' s.block# = i.block# AND i.obj# = o.obj# AND ' ||
              ' o.name not like ' || tmp_pattern
        into blk_oltp_high;
    end if;

    execute immediate 'select count(*) from deferred_stg$ ds ' ||
      ' where ds.obj# in (select obj# from obj$ ob' ||
                ' where ob.type# in (1,20) AND ob.owner# not in ' ||
                     '(select user# from user$ ' ||
                          ' where name in (''SYS'', ''SYSTEM'' ))) AND' ||
            ' bitand(ds.flags_stg, 4) = 4 AND ' ||
            ' bitand(ds.cmpflag_stg, 6) = 2 '
      into def_oltp_high;

    --Check for ADVANCED LOW seg, block, deferred seg
    execute immediate 'select count(*) from seg$ s, ind$ i, obj$ o ' ||
      ' where s.type# = 6 AND ' ||
            ' s.user# not in (select user# from user$ ' ||
                ' where name in (''SYS'', ''SYSTEM'' )) AND' ||
            ' bitand(s.spare1, 2048) = 2048 AND ' ||
            ' bitand(s.spare1, 16777216 + 1048576) = 1048576 AND ' ||
            ' s.ts# = i.ts# AND s.file# = i.file# AND ' ||
            ' s.block# = i.block# AND i.obj# = o.obj# AND ' ||
            ' o.name not like ' || tmp_pattern
      into num_oltp_low;

    if (num_oltp_low = 0) then
      blk_oltp_low := 0;
    else
      execute immediate 'select sum(blocks) from seg$ s, ind$ i, obj$ o  ' ||
        ' where s.type# = 6 AND ' ||
              ' s.user# not in (select user# from user$ ' ||
                  ' where name in (''SYS'', ''SYSTEM'' )) AND' ||
              ' bitand(s.spare1, 2048) = 2048 AND ' ||
              ' bitand(s.spare1, 16777216 + 1048576) = 1048576  AND ' ||
              ' s.ts# = i.ts# AND s.file# = i.file# AND ' ||
              ' s.block# = i.block# AND i.obj# = o.obj# AND ' ||
              ' o.name not like ' || tmp_pattern
        into blk_oltp_low;
    end if;

    execute immediate 'select count(*) from deferred_stg$ ds ' ||
      ' where ds.obj# in (select obj# from obj$ ob' ||
                ' where ob.type# in (1,20) AND ob.owner# not in ' ||
                      '(select user# from user$ ' ||
                          ' where name in (''SYS'', ''SYSTEM'' ))) AND' ||
            ' bitand(ds.flags_stg, 4) = 4 AND ' ||
            ' bitand(ds.cmpflag_stg, 6) = 4 '
      into def_oltp_low;

    --Summary
    feature_usage :=
        ' Advanced Index Compression feature usage: ' ||
                ' Segments Compressed for ADVANCED HIGH: ' ||
                  to_char(num_oltp_high) ||
        ', ' || ' Blocks Compressed for ADVANCED HIGH: ' ||
                  to_char(blk_oltp_high) ||
        ', ' || ' Deferred Segements Compressed for ADVANCED HIGH: ' ||
                  to_char(def_oltp_high) ||
        ', ' || ' Segments Compressed for ADVANCED LOW: ' ||
                  to_char(num_oltp_low) ||
        ', ' || ' Blocks Compressed for ADVANCED LOW: ' ||
                  to_char(blk_oltp_low) ||
        ', ' || ' Deferred Segements Compressed for ADVANCED LOW: ' ||
                  to_char(def_oltp_low);

    if (num_oltp_high + def_oltp_high + num_oltp_low + def_oltp_low > 0) then
      feature_boolean := 1;
      feature_info := to_clob(feature_usage);
    else
      feature_boolean := 0;
      feature_info := to_clob('Advanced Index Compression not detected');
    end if;
END;
/

