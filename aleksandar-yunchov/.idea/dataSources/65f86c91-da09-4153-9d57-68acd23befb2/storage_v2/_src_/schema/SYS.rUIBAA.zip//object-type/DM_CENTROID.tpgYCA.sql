create type dm_centroid
                                       as object
  (attribute_name        varchar2(4000)
  ,attribute_subname     varchar2(4000)
  ,mean                  number
  ,mode_value            varchar2(4000)
  ,variance              number)
/

