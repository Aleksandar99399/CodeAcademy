create trigger DISH_ORIGIN_ID_INCREMENT
    before insert
    on DISH_ORIGIN
    for each row
begin  
   if inserting then 
      if :NEW."ID" is null then 
         select DISH_ORIGIN_SEQ.nextval into :NEW."ID" from dual; 
      end if; 
   end if; 
end;
/

