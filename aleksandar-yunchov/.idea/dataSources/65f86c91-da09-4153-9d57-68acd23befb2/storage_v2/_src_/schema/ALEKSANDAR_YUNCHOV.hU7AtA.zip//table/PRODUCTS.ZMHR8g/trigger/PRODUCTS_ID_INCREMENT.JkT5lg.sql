create trigger PRODUCTS_ID_INCREMENT
    before insert
    on PRODUCTS
    for each row
begin  
   if inserting then 
      if :NEW."ID" is null then 
         select PRODUCTS_SEQ.nextval into :NEW."ID" from dual; 
      end if; 
   end if; 
end;
/

