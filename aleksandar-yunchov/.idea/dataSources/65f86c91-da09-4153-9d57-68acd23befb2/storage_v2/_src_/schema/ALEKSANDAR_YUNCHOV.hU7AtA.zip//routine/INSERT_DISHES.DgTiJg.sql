create PROCEDURE insert_dishes (name VARCHAR, dish_type NUMBER,dish_origin NUMBER,chef NUMBER)
IS
BEGIN

    INSERT INTO dishes (name,type,origin,chef)
    VALUES 
    (
    name,
    (SELECT ID FROM dish_type WHERE id = dish_type),
    (SELECT ID FROM dish_origin WHERE id = dish_origin),
    (SELECT ID FROM chefs WHERE id = chef)
    );

END;
/

