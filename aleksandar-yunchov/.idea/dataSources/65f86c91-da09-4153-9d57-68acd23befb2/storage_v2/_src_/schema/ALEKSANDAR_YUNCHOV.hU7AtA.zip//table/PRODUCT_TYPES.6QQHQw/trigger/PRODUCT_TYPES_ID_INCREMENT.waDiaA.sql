create trigger PRODUCT_TYPES_ID_INCREMENT
    before insert
    on PRODUCT_TYPES
    for each row
begin  
   if inserting then 
      if :NEW."ID" is null then 
         select PRODUCT_TYPE_SEQ.nextval into :NEW."ID" from dual; 
      end if; 
   end if; 
end;
/

