create trigger DISH_TYPE_ID_INCREMENT
    before insert
    on DISH_TYPE
    for each row
begin  
   if inserting then 
      if :NEW."ID" is null then 
         select DISH_TYPE_SEQ.nextval into :NEW."ID" from dual; 
      end if; 
   end if; 
end;
/

