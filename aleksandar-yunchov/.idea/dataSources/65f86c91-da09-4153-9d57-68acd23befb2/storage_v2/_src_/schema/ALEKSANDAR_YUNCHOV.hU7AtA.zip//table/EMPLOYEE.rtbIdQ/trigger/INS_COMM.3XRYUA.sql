create trigger INS_COMM
    before insert
    on EMPLOYEE
    for each row
BEGIN
 :NEW.salary := :NEW.salary*11;
END;
/

