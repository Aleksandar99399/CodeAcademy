create PROCEDURE insert_product (name VARCHAR, name_product  VARCHAR,unit_grams  NUMBER,calories  NUMBER,unit_price  NUMBER)
IS
BEGIN

    INSERT INTO products (name,type,unit_grams,calories,unit_price)
    VALUES (name,(SELECT ID FROM product_types WHERE name = name_product),unit_grams,calories,unit_price);

END;
/

