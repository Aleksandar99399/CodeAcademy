create trigger DISHES_ID_INCREMENT
    before insert
    on DISHES
    for each row
begin  
   if inserting then 
      if :NEW."ID" is null then 
         select DISHES_SEQ.nextval into :NEW."ID" from dual; 
      end if; 
   end if; 
end;
/

